from django.contrib.auth import logout
from django.shortcuts import render, redirect, get_object_or_404

from .forms import OrderForm, OrderString
from .models import Order


def home_view(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect('list_view')
        else:
            return redirect('order_view')
    return render(request, 'index.html')


def logout_view(request):
    logout(request)
    return redirect('login')
    # Redirect to a success page.


def add_order(request):
    # username = None
    # email = ''
    # if request.user.is_authenticated:
    #     username = request.user.username
    #     email = request.user.email
    if request.user.is_authenticated and not request.user.is_staff:
        # if request.user.is_staff:
        #     template = 'orderlist.html'
        # else:
        if request.method == "POST":
            form = OrderForm(request.POST)
            if form.is_valid():
                new_order = form.save(commit=False)
                new_order.author = request.user
                new_order.save()
                if new_order.created_on.hour in (13,14):
                    print('!!!INFO!!! will send email to admin')
                else:
                    print('!!INFO!!! will not send email')
                return redirect('order_view') # редиректим на страницу заказа
        return render(request, 'order.html', {'form': OrderForm()})
    return redirect('home_view')


def order_list(request):
    if request.user.is_authenticated and request.user.is_staff:
        if request.method == "POST":
            form = OrderString(request.POST)
            if form.is_valid():
                c = get_object_or_404(Order, slug=form.cleaned_data['slug'])
                if form.cleaned_data['action'] == 'Update':
                    c.order_item = form.cleaned_data['order_item']
                    c.cost = form.cleaned_data['cost']
                    c.comment = ''.join(form.cleaned_data['comment'])
                    c.save()
                elif form.cleaned_data['action'] == 'Delete':
                    c.delete()
        return render(request, 'orderlist.html', {'orders':Order.objects.all()})
    return redirect('home_view')


#
#
# def add_comment_to_post(request, slug):
#     post = get_object_or_404(Post, slug=slug)
#     if request.method == "POST":
#         form = CommentForm(request.POST)
#         if form.is_valid():
#             comment = form.save(commit=False)
#             comment.post = post
#             comment.save()
#             return redirect('post_detail', slug=post.slug)
#     else:
#         form = CommentForm()
#     return render(request, 'add_comment_to_post.html', {'form': form})



